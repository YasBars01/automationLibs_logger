from loggerLibrary.logger import Logger
from loggerLibrary.old_logger import OldLogger
