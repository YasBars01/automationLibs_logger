from logger import Logger
from old_logger import OldLogger