from dotenv import load_dotenv, find_dotenv
load_dotenv(find_dotenv())
from loggerLibrary.logger import Logger
from loggerLibrary.old_logger import OldLogger
